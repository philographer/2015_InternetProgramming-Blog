-- MySQL dump 10.13  Distrib 5.6.23, for Win64 (x86_64)
--
-- Host: 165.246.43.209    Database: db12121518
-- ------------------------------------------------------
-- Server version	5.6.24-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `my_visitor`
--

DROP TABLE IF EXISTS `my_visitor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `my_visitor` (
  `v_id` int(11) NOT NULL AUTO_INCREMENT,
  `v_title` varchar(20) NOT NULL,
  `v_adddate` datetime DEFAULT CURRENT_TIMESTAMP,
  `v_readcount` int(11) DEFAULT '0',
  `v_author` varchar(45) DEFAULT NULL,
  `v_password` varchar(45) DEFAULT NULL,
  `v_content` varchar(2000) DEFAULT NULL,
  `v_upddate` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`v_id`,`v_title`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `my_visitor`
--

LOCK TABLES `my_visitor` WRITE;
/*!40000 ALTER TABLE `my_visitor` DISABLE KEYS */;
INSERT INTO `my_visitor` VALUES (1,'1번글','2015-06-21 14:46:30',0,'yoohoogun114','1234','1234','2015-06-21 14:46:30'),(2,'2번글','2015-06-21 14:46:45',2,'yoohoogun114','1234','2번글','2015-06-21 14:46:45'),(3,'3번글','2015-06-21 14:46:53',0,'yoohoogun114','1234','3','2015-06-21 14:46:53'),(4,'4번글','2015-06-21 14:46:59',0,'yoohoogun114','2134','1234','2015-06-21 14:46:59'),(5,'5번글','2015-06-21 14:47:04',0,'yoohoogun114','1234','2134','2015-06-21 14:47:04'),(6,'1234','2015-06-21 14:47:08',1,'yoohoogun114','1234','2134','2015-06-21 14:47:08'),(7,'7번글','2015-06-21 14:47:14',0,'yoohoogun114','12321','213213','2015-06-21 14:47:14'),(8,'21321','2015-06-21 14:47:18',0,'yoohoogun114','321321','3213213','2015-06-21 14:47:18'),(9,'12321321','2015-06-21 14:47:22',0,'yoohoogun114','321321','321321321','2015-06-21 14:47:22'),(10,'21321321','2015-06-21 14:47:25',0,'yoohoogun114','3213213','213213','2015-06-21 14:47:25'),(11,'21321321','2015-06-21 14:47:29',2,'yoohoogun114','3213321','123123','2015-06-21 14:47:29'),(12,'2132321','2015-06-21 14:47:33',0,'yoohoogun114','3213213','213213','2015-06-21 14:47:33');
/*!40000 ALTER TABLE `my_visitor` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-06-22  1:10:44
