-- MySQL dump 10.13  Distrib 5.6.23, for Win64 (x86_64)
--
-- Host: 165.246.43.209    Database: db12121518
-- ------------------------------------------------------
-- Server version	5.6.24-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `my_useraccount`
--

DROP TABLE IF EXISTS `my_useraccount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `my_useraccount` (
  `u_id` varchar(16) NOT NULL,
  `u_password` varchar(16) NOT NULL,
  `u_nickname` varchar(50) NOT NULL,
  `Profile` blob,
  `u_address` varchar(50) NOT NULL,
  `u_birthday` varchar(50) DEFAULT NULL,
  `u_telePhone` varchar(20) DEFAULT NULL,
  `u_chickPoint` varchar(12) DEFAULT NULL,
  `u_eatoutPoint` varchar(2) DEFAULT NULL,
  `u_LikeMostFood` varchar(50) DEFAULT NULL,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`u_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `my_useraccount`
--

LOCK TABLES `my_useraccount` WRITE;
/*!40000 ALTER TABLE `my_useraccount` DISABLE KEYS */;
INSERT INTO `my_useraccount` VALUES ('123213','123123','123123',NULL,'경기,인천','2015-06-05T02:03','123123213','8','7','213213','2015-06-07 19:16:40'),('Administrator','Administrator','Administrator',NULL,'서울','2015-06-19T14:13','Administrator','5','5','Administrator','2015-06-19 21:10:59'),('cn5288','ghrbsdl114','티메르',NULL,'경기,인천','0213-06-03T13:02','213123','7','8','123123','2015-06-08 10:58:32'),('ghrbsdl123123','123123123','123123123',NULL,'서울','2015-06-12T14:21','213213123','5','5','123123123','2015-06-21 13:08:45'),('yoohoogun113','ghrbsdl114','티메',NULL,'선택해주세요','0012-06-09T12:23','213213','7','6','123123','2015-06-07 19:28:49'),('yoohoogun114','ghrbsdl114','티메르',NULL,'경기,인천','2015-06-04T14:13','213213123','5','7','치즈','2015-06-07 19:45:58'),('yoohoogun14','ghrbsdl114','티메르',NULL,'경기,인천','1994-04-03T02:21','213213213','7','6','213123','2015-06-07 18:55:04');
/*!40000 ALTER TABLE `my_useraccount` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-06-22  1:10:43
